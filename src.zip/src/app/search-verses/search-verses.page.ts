import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-verses',
  templateUrl: './search-verses.page.html',
  styleUrls: ['./search-verses.page.scss'],
})
export class SearchVersesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
