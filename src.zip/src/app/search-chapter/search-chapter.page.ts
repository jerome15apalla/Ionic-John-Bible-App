import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-chapter',
  templateUrl: './search-chapter.page.html',
  styleUrls: ['./search-chapter.page.scss'],
})
export class SearchChapterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
