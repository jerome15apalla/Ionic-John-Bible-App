import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-john-verses',
  templateUrl: './john-verses.page.html',
  styleUrls: ['./john-verses.page.scss'],
})
export class JohnVersesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
